import xml.etree.ElementTree as ET
import sys, os
#import pprint
from datetime import datetime
from pymongo import MongoClient

try: 
    conn = MongoClient() 
    print("Connected successfully!!!") 
except:   
    print("Could not connect to MongoDB") 

#### 21 Languages can give good spread.
#### 27 Country Lists

startTime = datetime.now()

#sprint 'start time :' + str(startTime)


tree = ET.parse("pubmed_result.xml")
root = tree.getroot()

print(len(root))

newRoot = ET.Element("PubmedArticle")

f = open("pubmed_new.xml", "a")

print ("Time it took to load the file")
print (datetime.now() - startTime)

scripttime = datetime.now()

for i in range(1,5084):
    #item = {'Title':'','articleTitle':'','publishdt':'','authors':[],'abstract':[]}
    abstractTxt =''

    print(root.findtext('./PubmedArticle['+str(i)+']/MedlineCitation/PMID'))

    article = root.find('./PubmedArticle['+str(i)+']/MedlineCitation/Article')

    if article is None:
        break

    subTree = ET.SubElement(newRoot, "Article")
    
    #title= article.findtext('./Journal/Title')
    title= article.find('./Journal/Title')
    subTree.append( title )

    #articleTitle= article.findtext('./ArticleTitle')
    articleTitle= article.find('./ArticleTitle')
    subTree.append( articleTitle )

    AbstractText = ET.Element("AbstractText")
    for abstract in article.findall('./Abstract/AbstractText'):
        #print abstract.text
        #if abstract.text != '' or abstract is not None or abstract.text != "None":
            #abstractTxt += str(abstract.text)
        #else:
            #print "in Else"+ abstract
            
        #AbstractText.text = abstractTxt
        subTree.append(abstract)

    for authors in article.findall('./AuthorList/Author'):
        Author = ET.Element("Author")
        
        Initials = authors.find('Initials')
        ForeName = authors.find('ForeName')
        LastName = authors.find('LastName')
        
        if Initials is not None:
            IName = Initials.text
        if ForeName is not None:
            FName = ForeName.text
        if LastName is not None:
            LName = LastName.text
            
        Author.text = IName + ' ' + FName + ' ' + LName
        
        subTree.append(Author)

    nodexml = ET.tostring(subTree,'utf-8')
    f.write(str(nodexml))

    print (i , datetime.now() - scripttime)
    scripttime = datetime.now()
    if (i % 10) == 0:
        f.flush()
        os.fsync(f.fileno())
    

f.close()

print ("Final Execution Time :")
print (datetime.now() - startTime) 

#print pubmed
