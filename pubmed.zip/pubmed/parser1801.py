import xml.etree.ElementTree as ET
import sys, os
#import pprint
from datetime import datetime
from pymongo import MongoClient


#### 21 Languages can give good spread.
#### 27 Country Lists

startTime = datetime.now()
print('start time :' + str(startTime))

try: 
    conn = MongoClient() 
    print("Connected successfully!!!") 
except:   
    print("Could not connect to MongoDB") 

# database & Collection
db = conn.pubmed  
mongoArticle = db.article

tree = ET.parse("pubmed_result1.xml")
root = tree.getroot()

print(len(root))

print ("Time it took to load the file")
print (datetime.now() - startTime)

scripttime = datetime.now()

for i in range(1,5085):
    item = {'PMID':'','Title':'','articleTitle':'','pubDate':'','authors':[],'abstract':[],'Keyword':[]}

    item['PMID'] = root.findtext('./PubmedArticle['+str(i)+']/MedlineCitation/PMID')

    for Keyword in root.findall('./PubmedArticle['+str(i)+']/MedlineCitation/KeywordList/Keyword'):
        item['Keyword'].append(Keyword.text)
    
    article = root.find('./PubmedArticle['+str(i)+']/MedlineCitation/Article')

    if article is None:
        break

    item['Title'] = article.findtext('./Journal/Title')
    
    item['articleTitle'] = article.findtext('./ArticleTitle')


    #Journal/JournalIssue/PubDate/Year
    Year = article.findtext('./Journal/JournalIssue/PubDate/Year') if article.findtext('./Journal/JournalIssue/PubDate/Year') else "0000"
    Month = article.findtext('./Journal/JournalIssue/PubDate/Month') if article.findtext('./Journal/JournalIssue/PubDate/Month') else "XXX"
    Day = article.findtext('./Journal/JournalIssue/PubDate/Day') if article.findtext('./Journal/JournalIssue/PubDate/Day') else "00"

    item['pubDate'] = Year+"-"+Month+"-"+Day
    
    for abstract in article.findall('./Abstract/AbstractText'):
        if abstract is not None:
            item['abstract'].append(abstract.text)

    for authors in article.findall('./AuthorList/Author'):
        
        Initials = authors.find('Initials')
        ForeName = authors.find('ForeName')
        LastName = authors.find('LastName')
        
        if Initials is not None:
            IName = Initials.text
        if ForeName is not None:
            FName = ForeName.text
        if LastName is not None:
            LName = LastName.text
            
        Author = IName + ' ' + FName + ' ' + LName
        
        item['authors'].append(Author)

    
    recId = mongoArticle.insert_one(item)
    #print("Data inserted with record id:",recId) 
    print (i , datetime.now() - scripttime)
    scripttime = datetime.now()

print ("Final Execution Time :")
print (datetime.now() - startTime) 

