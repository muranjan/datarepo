import xml.etree.ElementTree as ET
import sys
#import pprint
from datetime import datetime


startTime = datetime.now()

print "start time : " + str(startTime)


tree = ET.parse("pubmed_result1.xml")
root = tree.getroot()

print "Time it took to load the file"
print datetime.now() - startTime

scripttime = datetime.now()
pubmed =[]
for i in range(5100):
    item = {'Title':'','articleTitle':'','publishdt':'','authors':[],'abstract':[]}

    article = root.find('./PubmedArticle['+str(i)+']/MedlineCitation/Article')

    if article is None:
        break
    
    title= article.findtext('./Journal/Title')
    item['Title'] = title

    articleTitle= article.findtext('./ArticleTitle')
    item['articleTitle'] = articleTitle

    for abstract in article.findall('./Abstract/AbstractText'):
        if abstract is not None:
            item['abstract'].append(abstract.text)

    for authors in article.findall('./AuthorList/Author'):
        author ={'Initials':'','ForeName':'','LastName':''}
        Initials = authors.find('Initials')
        ForeName = authors.find('ForeName')
        LastName = authors.find('LastName')
        
        if Initials is not None:
            author['Initials']  = Initials
        if ForeName is not None:
            author['ForeName']  = ForeName
        if LastName is not None:
            author['LastName']  = LastName
        item['authors'].append(author)

    #print item
    pubmed.append(item)
    print i , datetime.now() - scripttime
    scripttime = datetime.now() 
    

#pprint.pprint(pubmed)


print "Final Execution Time :"
print datetime.now() - startTime 

#print pubmed
