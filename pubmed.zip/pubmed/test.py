import xml.etree.ElementTree as ET

print "start"

        
tree = ET.parse("pubmed_result.xml")
root = tree.getroot()

for child in root:
  print({x.tag for x in root.findall(child.tag+"/*")})
