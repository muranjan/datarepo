import xml.etree.ElementTree as ET
import sys, os
#import pprint
from datetime import datetime
from pymongo import MongoClient


#### 21 Languages can give good spread.
#### 27 Country Lists

startTime = datetime.now()
print('start time :' + str(startTime))


tree = ET.parse("pubmed_result1.xml")
root = tree.getroot()

print(len(root))


print ("Time it took to load the file")
print (datetime.now() - startTime)

scripttime = datetime.now()

for i in range(1,5085):

    print (i, root.findtext('./PubmedArticle['+str(i)+']/MedlineCitation/PMID'))
    if(i%100)==0: 
    	print (i , datetime.now() - scripttime)
    	scripttime = datetime.now()

print ("Final Execution Time :")
print (datetime.now() - startTime) 

