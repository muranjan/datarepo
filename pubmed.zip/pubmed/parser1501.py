import xml.etree.ElementTree as ET
#import pprint
from datetime import datetime


startTime = datetime.now()

print "start time : " + str(startTime)


tree = ET.parse("pubmed_result1.xml")
root = tree.getroot()

print "Time it took to load the file"
print datetime.now() - startTime

scripttime = datetime.now()
pubmed =[]
for i in range(3):
    item = {'Title':'','articleTitle':'','publishdt':'','authors':[],'abstract':''}

    article = root.find('./PubmedArticle['+str(i)+']/MedlineCitation/Article')

    title= root.findtext('./PubmedArticle['+str(i)+']/MedlineCitation/Article/Journal/Title')
    item['Title']= title

    articleTitle= root.findtext('./PubmedArticle['+str(i)+']/MedlineCitation/Article/ArticleTitle')
    item['articleTitle'] = articleTitle

    for abstract in root.findall('./PubmedArticle['+str(i)+']/MedlineCitation/Article/Abstract/AbstractText'):
            item['abstract'] += " "+abstract.text

    for authors in root.findall('./PubmedArticle['+str(i)+']/MedlineCitation/Article/AuthorList/Author'):
        author =''
        author += authors.find('Initials').text +' '+ authors.find('ForeName').text + ' ' +  authors.find('LastName').text
        item['authors'].append(author)

    #print item
    pubmed.append(item)
    print datetime.now() - scripttime
    scripttime = datetime.now() 
    

#pprint.pprint(pubmed)


print "Final Execution Time :"
print datetime.now() - startTime 
