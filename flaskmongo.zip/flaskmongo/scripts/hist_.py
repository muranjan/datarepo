import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
from datetime import datetime
from pymongo import MongoClient
import collections

startTime = datetime.now()
print('start time :' + str(startTime))

try: 
    conn = MongoClient() 
    print("Connected successfully!!!") 
except:   
    print("Could not connect to MongoDB") 

# database & Collection
db = conn.pubmed  
mongoArticle = db.article

def _month(i):
	if i in ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']:
		#print( i)
		return i
	elif "-" in i:
		j=str(i[0:2])
		#print (j, i)

		switcher={"01":'Jan',"02":'Feb',"03":'Mar',"04":'Apr',"05":'May',"06":'Jun',"07":'Jul',"08":'Aug',"09":'Sep',"10":'Oct',"11":'Nov',"12":'Dec'}
		k = switcher.get(j,"XXX")
		#print (k)
		return k 

dateDict = mongoArticle.aggregate([{'$project':{'_id':0,'year':{'$substr':["$pubDate",0,4]}, 'month':{'$substr':["$pubDate",5,3]},'day':{'$substr':["$pubDate",9,2]}}}])

years = {'0000':0,'51-60':0,'61-70':0,'71-80':0,'81-90':0,'91-2k':0,'01-10':0,'11-20':0}
months =[]
days =[]

#### Just to test if _month function is returning correct conversion.
#Counter({'XXX': 829, 'Dec': 345, 'Sep': 341, 'Feb': 329, 'Apr': 325, 'Oct': 324, 'Jan': 315, 'Nov': 312, 'Jul': 297, 'May': 295, 'Jun': 290, 'Mar': 286, 'Aug': 275, '01-': 53, '10-': 49, '09-': 47, '07-': 47, '08-': 43, '03-': 43, '12-': 42, '02-': 39, '05-': 38, '06-': 35, '11-': 35, '04-': 34})
#Counter({None: 829, 'Sep': 388, 'Dec': 387, 'Oct': 373, 'Jan': 368, 'Feb': 368, 'Apr': 359, 'Nov': 347, 'Jul': 344, 'May': 333, 'Mar': 329, 'Jun': 325, 'Aug': 318})
######################################################################

for doc in dateDict:
	yr=int(doc['year'])
	if  yr < 1:
		#print (yr)
		years['0000'] +=1
	elif yr <= 1960 :
		years['51-60'] +=1
	elif yr <= 1970 :
		years['61-70'] +=1
	elif yr <= 1980 :
		years['71-80'] +=1
	elif yr <= 1990 :
		years['81-90'] +=1
	elif yr <= 2000 :
		years['91-2k'] +=1
	elif yr <= 2010 :
		years['01-10'] +=1
	elif yr <= 2020 :
		years['11-20'] +=1
	else:
		years['0000'] +=1
	
	months.append(_month(doc['month']))
	days.append(doc['day'])	
	#print (doc)

#print(years)
#print(months)
#print(days)

#y=collections.Counter(years)
m=collections.Counter(months)
d=collections.Counter(days)

#plt.bar(years.keys(), years.values())



# number of bars
N = 8

# plot a random bar graph
fig = plt.figure()
ax = fig.add_subplot(111)
bars = ax.bar(years.keys(),years.values())

# change the colors according to the color map 'jet'
for i, b in enumerate(bars):
    b.set_color(plt.cm.jet(1. * i / (N - 1)))


#plt.show()

plt.savefig("YearBarPlot.png")
