import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
from datetime import datetime
from pymongo import MongoClient
import collections, operator

startTime = datetime.now()
print('start time :' + str(startTime))

try: 
    conn = MongoClient() 
    print("Connected successfully!!!") 
except:   
    print("Could not connect to MongoDB") 

# database & Collection
db = conn.pubmed  
mongoArticle = db.article

def _month(i):
	if i in ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']:
		#print( i)
		return i
	elif "-" in i:
		j=str(i[0:2])
		#print (j, i)

		switcher={"01":'Jan',"02":'Feb',"03":'Mar',"04":'Apr',"05":'May',"06":'Jun',"07":'Jul',"08":'Aug',"09":'Sep',"10":'Oct',"11":'Nov',"12":'Dec'}
		k = switcher.get(j,'XXX')
		#print (k)
		return k
	else:
		return 'XXX' 

dateDict = mongoArticle.aggregate([{'$project':{'_id':0,'year':{'$substr':["$pubDate",0,4]}, 'month':{'$substr':["$pubDate",5,3]},'day':{'$substr':["$pubDate",9,2]}}}])

years = {'0000':0,'1951-1960':0,'1961-1070':0,'1971-1080':0,'1981-1090':0,'1991-2000':0,'2001-2010':0,'2011-2020':0}
months =[]
days =[]

#### Just to test if _month function is returning correct conversion.
#Counter({'XXX': 829, 'Dec': 345, 'Sep': 341, 'Feb': 329, 'Apr': 325, 'Oct': 324, 'Jan': 315, 'Nov': 312, 'Jul': 297, 'May': 295, 'Jun': 290, 'Mar': 286, 'Aug': 275, '01-': 53, '10-': 49, '09-': 47, '07-': 47, '08-': 43, '03-': 43, '12-': 42, '02-': 39, '05-': 38, '06-': 35, '11-': 35, '04-': 34})
#Counter({None: 829, 'Sep': 388, 'Dec': 387, 'Oct': 373, 'Jan': 368, 'Feb': 368, 'Apr': 359, 'Nov': 347, 'Jul': 344, 'May': 333, 'Mar': 329, 'Jun': 325, 'Aug': 318})
######################################################################

for doc in dateDict:
	yr=int(doc['year'])
	if  yr < 1:
		#print (yr)
		years['0000'] +=1
	elif yr <= 1960 :
		years['1951-1960'] +=1
	elif yr <= 1970 :
		years['1961-1070'] +=1
	elif yr <= 1980 :
		years['1971-1080'] +=1
	elif yr <= 1990 :
		years['1981-1090'] +=1
	elif yr <= 2000 :
		years['1991-2000'] +=1
	elif yr <= 2010 :
		years['2001-2010'] +=1
	elif yr <= 2020 :
		years['2011-2020'] +=1
	else:
		years['0000'] +=1
	
	months.append(_month(doc['month']))
	days.append(doc['day'])	
	#print (doc)

#print(years)
#print(months)
#print(days)

#y=collections.Counter(years)
m={'Jan':0,'Feb':0,'Mar':0,'Apr':0,'May':0,'Jun':0,'Jul':0,'Aug':0,'Sep':0,'Oct':0,'Nov':0,'Dec':0}
mnth=collections.Counter(months)
for key in mnth:
	m[key]=mnth[key]
print(m)	
d=collections.Counter(days)


# number of bars
N = 8

# plot a random bar graph
fig = plt.figure()
ax = fig.add_subplot(111)
bars = ax.bar(years.keys(),years.values())

ax.set_title("Articles published over decades")
# change the colors according to the color map 'jet'
for i, b in enumerate(bars):
    b.set_color(plt.cm.jet(1. * i / (N - 1)))

plt.xticks(rotation=45)
plt.tick_params(axis='x',which='major',labelsize=6)
#plt.show()

plt.savefig("YearBarPlot.png")

# number of bars
N = 13

# plot a random bar graph
fig = plt.figure()
ax = fig.add_subplot(111)

bars = ax.bar(m.keys(),m.values())

ax.set_title("Monthly distribution of Articles published")
# change the colors according to the color map 'jet'
for i, b in enumerate(bars):
    b.set_color(plt.cm.jet(1. * i / (N - 1)))

plt.xticks(rotation=45)
plt.tick_params(axis='x',which='major',labelsize=6)
#plt.show()

plt.savefig("MonthBarPlot.png")
