from wordcloud import WordCloud, STOPWORDS
from pymongo import MongoClient
import matplotlib.pyplot as plt
import pandas as pd


try: 
    conn = MongoClient() 
    print("Connected successfully!!!") 
except:   
    print("Could not connect to MongoDB") 

# database & Collection
db = conn.pubmed  
mongoArticle = db.article

keyword = ' '
stopwords = set(STOPWORDS)

ATitle = mongoArticle.find({},{'_id':0,'articleTitle':1})

for doc in ATitle:
	title = doc['articleTitle']
	title = str(title)
	tokens = title.split()

	#convert each token into lowercase
	for i in range(len(tokens)):
		tokens[i] = tokens[i].lower()

	for words in tokens:
		keyword = keyword + words + ' '
	#print(keyword)

wordcloud = WordCloud(background_color="white", max_words=200, width=400, height=400,min_font_size=7, random_state=1).generate(keyword)

plt.figure(figsize = (8,8), facecolor = None)
plt.imshow(wordcloud)
plt.axis("off")
plt.tight_layout(pad = 0 )

plt.savefig("WordCount.png")
