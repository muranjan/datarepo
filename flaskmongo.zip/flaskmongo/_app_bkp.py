from flask import Flask, render_template,request,redirect,url_for # For flask implementation
from bson import ObjectId # For ObjectId to work
from pymongo import MongoClient
import os, sys

app = Flask(__name__)
title = "Article Analytics with Flask and MongoDB"
heading = "Pubmed Article Analytics with Flask and MongoDB"

#conn = MongoClient() #host uri
#db = conn.pubmed    #Select the database
#articles = db.articles #Select the collection name

try: 
    conn = MongoClient() 
    print("Connected successfully!!!") 
except:   
    print("Could not connect to MongoDB") 

# database & Collection
db = conn.pubmed  
articles = db.article


def redirect_url():
    return request.args.get('next') or \
           request.referrer or \
           url_for('index')

@app.route("/list")
def lists ():
	#Display the all Tasks
	#articles_l = articles.find({},{'PMID':1,'Title':1,'articleTitle':1,'pubDate':1, 'abstract':1,'Keyword':1,'authors':1,'_id':0 },
		#{"$project": { 'shortabstract':{'$substr': ["$abstract", 1, 200]}}}
		#).limit(10)
	#articles_l = articles.aggregate( [{"$project": { 'shortabstract':{'$substr': ["$abstract", 1, 200]}}}, {'PMID':1,'Title':1,'articleTitle':1,'pubDate':1, 'abstract':1,'Keyword':1,'authors':1,'_id':0 }]).limit(10)
	#articles_l = articles.aggregate( [{"$project": { 'shortabstract':{'$substr': ["$title", 1, 20]},'PMID':1,'Title':1,'articleTitle':1,'pubDate':1, 'abstract':1,'Keyword':1,'authors':1,'_id':0}}])
	articles_l = articles.find( {},{'PMID':1,'Title':1,'articleTitle':1,'pubDate':1, 'abstract':1,'Keyword':1,'authors':1,'_id':0}).limit(50)
	#print(type(articles_l), file=sys.stderr)
	a1="active"
	return render_template('index.html',a1=a1,articles=list(articles_l),t=title,h=heading)

@app.route("/")
@app.route("/list")
def tasks ():
	#Display the Uncompleted Tasks
	articles_l = articles.find({"done":"no"})
	a2="active"
	return render_template('index.html',a2=a2,articles=articles_l,t=title,h=heading)


@app.route("/completed")
def completed ():
	#Display the Completed Tasks
	articles_l = articles.find({"done":"yes"})
	a3="active"
	return render_template('index.html',a3=a3,articles=articles_l,t=title,h=heading)

@app.route("/done")
def done ():
	#Done-or-not ICON
	id=request.values.get("_id")
	task=articles.find({"_id":ObjectId(id)})
	if(task[0]["done"]=="yes"):
		articles.update({"_id":ObjectId(id)}, {"$set": {"done":"no"}})
	else:
		articles.update({"_id":ObjectId(id)}, {"$set": {"done":"yes"}})
	redir=redirect_url()	

	return redirect(redir)

@app.route("/action", methods=['POST'])
def action ():
	#Adding a Task
	name=request.values.get("name")
	desc=request.values.get("desc")
	date=request.values.get("date")
	pr=request.values.get("pr")
	articles.insert({ "name":name, "desc":desc, "date":date, "pr":pr, "done":"no"})
	return redirect("/list")

@app.route("/remove")
def remove ():
	#Deleting a Task with various references
	key=request.values.get("_id")
	articles.remove({"_id":ObjectId(key)})
	return redirect("/")

@app.route("/update")
def update ():
	id=request.values.get("_id")
	task=articles.find({"_id":ObjectId(id)})
	return render_template('update.html',tasks=task,h=heading,t=title)

@app.route("/action3", methods=['POST'])
def action3 ():
	#Updating a Task with various references
	name=request.values.get("name")
	desc=request.values.get("desc")
	date=request.values.get("date")
	pr=request.values.get("pr")
	id=request.values.get("_id")
	articles.update({"_id":ObjectId(id)}, {'$set':{ "name":name, "desc":desc, "date":date, "pr":pr }})
	return redirect("/")

@app.route("/search", methods=['GET'])
def search():
	#Searching a Task with various references

	key=request.values.get("key")
	refer=request.values.get("refer")
	if(key=="_id"):
		articles_l = articles.find({refer:ObjectId(key)})
	else:
		articles_l = articles.find({'Keyword':key})
	return render_template('searchlist.html',articles=articles_l,t=title,h=heading)

if __name__ == "__main__":

    app.run()
