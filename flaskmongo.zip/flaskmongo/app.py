from flask import Flask, render_template,request,redirect,url_for # For flask implementation
from bson import regex,ObjectId # For ObjectId to work
from pymongo import MongoClient
import os, sys

app = Flask(__name__)
title = "Article Analytics with Flask and MongoDB"
heading = "Pubmed Article Analytics with Flask and MongoDB"

#conn = MongoClient() #host uri
#db = conn.pubmed    #Select the database
#articles = db.articles #Select the collection name

try: 
    conn = MongoClient() 
    print("Connected successfully!!!") 
except:   
    print("Could not connect to MongoDB") 

# database & Collection
db = conn.pubmed  
articles = db.article


def redirect_url():
    return request.args.get('next') or \
           request.referrer or \
           url_for('index')

@app.route("/")
@app.route("/list")
def lists ():
	#Display the all Tasks
	#articles_l = articles.find({},{'PMID':1,'Title':1,'articleTitle':1,'pubDate':1, 'abstract':1,'Keyword':1,'authors':1,'_id':0 },
		#{"$project": { 'shortabstract':{'$substr': ["$abstract", 1, 200]}}}
		#).limit(10)
	#articles_l = articles.aggregate( [{"$project": { 'shortabstract':{'$substr': ["$abstract", 1, 200]}}}, {'PMID':1,'Title':1,'articleTitle':1,'pubDate':1, 'abstract':1,'Keyword':1,'authors':1,'_id':0 }]).limit(10)
	#articles_l = articles.aggregate( [{"$project": { 'shortabstract':{'$substr': ["$title", 1, 20]},'PMID':1,'Title':1,'articleTitle':1,'pubDate':1, 'abstract':1,'Keyword':1,'authors':1,'_id':0}}])
	articles_l = articles.find( {},{'PMID':1,'Title':1,'articleTitle':1,'pubDate':1, 'abstract':1,'Keyword':1,'authors':1,'_id':0}).limit(50)
	#print(type(articles_l), file=sys.stderr)
	a1="active"
	return render_template('index.html',a1=a1,articles=list(articles_l),t=title,h=heading)


@app.route("/search", methods=['GET'])
def search():
	#Searching a Task with various references

	key=request.values.get("key")
	refer=request.values.get("refer")
	if(key.strip()==""):
		articles_l = []
		recordcount = 0
	else:
		articles_l   = articles.find({"$or":[{'Keyword':{'$regex':".*"+key+".*"}},{'articleTitle':{'$regex':".*"+key+".*"}}]})
		recordcount = articles_l.count()
	return render_template('searchlist.html',articles=articles_l,reccount=recordcount,t=title,h=heading)

@app.route('/insights')
def insights():
	return render_template('graph.html' )


if __name__ == "__main__":

    app.run()
